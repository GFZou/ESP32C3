
#ifdef __cplusplus
extern "C" {
#endif

void * ws2812_main(void * p);


#ifdef __cplusplus
}
#endif

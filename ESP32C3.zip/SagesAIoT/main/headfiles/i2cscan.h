
#ifdef __cplusplus
extern "C" {
#endif

void * i2cscan_main(void);


#ifdef __cplusplus
}
#endif
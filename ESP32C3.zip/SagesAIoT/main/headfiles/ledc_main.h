
#ifdef __cplusplus
extern "C" {
#endif

void * ledc_main(void * p);


#ifdef __cplusplus
}
#endif

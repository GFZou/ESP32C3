
#ifdef __cplusplus
extern "C" {
#endif

void * le_GATTServer_main(void * p);


#ifdef __cplusplus
}
#endif

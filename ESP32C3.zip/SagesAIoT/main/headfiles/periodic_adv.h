
#ifdef __cplusplus
extern "C" {
#endif

void * periodic_adv_main(void * p);


#ifdef __cplusplus
}
#endif
